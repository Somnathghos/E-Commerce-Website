'use strict';



// ------ add event on element



// ------ navbar toggle



// ------ header sticky & back top btn active


// ------ scroll reveal effect